# Blender capsule walker results

Capsule 1.8 m tall, radius 0.32 m, step-up 0.25 m. Door leaves ignored; frames and all other meshes tested.
Waypoints: every stair tread, landing centres, corridor centre-lines.

| Route | Result | Reached | Min head (m) | Stuck node | Notes |
|---|---|---|---|---|---|
| main_to_stair1_up | PASS | 30/30 | 2.289 |  |  |
| stair1_down_to_main | PASS | 30/30 | 2.289 |  |  |
| service_to_stair2_up | PASS | 35/35 | 2.29 |  |  |
| stair2_down_to_service | PASS | 35/35 | 2.289 |  |  |
| exterior_stair_up | PASS | 32/32 | 2.29 |  |  |
| exterior_stair_down | PASS | 32/32 | 2.289 |  |  |
| ground_loop | PASS | 12/12 | 3.95 |  |  |
| upper_loop | PASS | 21/21 | 2.4 |  |  |

**8 of 8 routes passed.**
