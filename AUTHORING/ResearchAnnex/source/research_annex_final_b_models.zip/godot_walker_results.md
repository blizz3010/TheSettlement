# Godot CharacterBody3D walker results

Test-only scene. Trimesh collision built at runtime from the building GLB. Shipped GLB has no collision. Door leaves were hidden/skipped; frames kept. Capsule 1.8 m × r 0.32 m, floor_max_angle 45°, floor_snap_length 0.4 m, test_move step-up 0.25 m on actual stair geometry (no ramps). Waypoint reach 0.40 m H / 0.50 m V on landings and corridors; tightened to 0.18 m H / 0.12 m V on consecutive stair-tread waypoints so the capsule must actually step each tread (spacing 0.30 m / 0.175 m). No runtime nudge, teleport, or waypoint skip. Sliding along walls via move_and_slide is allowed. Steering look-ahead is disabled (it overshot the 0.40 m reach window on earlier routes).

| Route | Reached all? | Reached | Time (s) | Min head (m) | Max floor angle | Horiz. error (m) | Stall collider | Notes |
|---|---|---|---|---|---|---|---|---|
| main_to_stair1_up | yes | 30/30 | 11.62 | 2.252 | 45.4° | 0.462 |  | PASS — walked the polyline on actual geometry. |
| stair1_down_to_main | yes | 30/30 | 11.00 | 2.252 | 45.5° | 0.465 |  | PASS — walked the polyline on actual geometry. |
| service_to_stair2_up | yes | 35/35 | 13.90 | 2.172 | 45.4° | 0.498 |  | PASS — walked the polyline on actual geometry. |
| stair2_down_to_service | yes | 35/35 | 13.25 | 2.177 | 45.5° | 0.477 |  | PASS — walked the polyline on actual geometry. |
| exterior_stair_up | yes | 32/32 | 8.53 | 2.172 | 44.9° | 0.468 |  | PASS — walked the polyline on actual geometry. |
| exterior_stair_down | yes | 32/32 | 8.85 | 2.177 | 45.4° | 0.483 |  | PASS — walked the polyline on actual geometry. |
| ground_loop | yes | 12/12 | 21.07 | 3.912 | 0.0° | 0.489 |  | PASS — walked the polyline on actual geometry. |
| upper_loop | yes | 21/21 | 30.77 | 2.362 | 0.0° | 0.498 |  | PASS — walked the polyline on actual geometry. |
