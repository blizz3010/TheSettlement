# Research Annex phase-1 geometry verification

**Overall: PASS**

## Stairs (under-flight headroom, openings, riser/tread)

| Stair | Risers | Riser | Tread | Width | Min under-flight | Opening | Result |
|---|---|---|---|---|---|---|---|
| Stair1 | 24 | 0.175 | 0.300 | 1.80 | 2.550 m | clear | PASS |
  - min at flight f1 i=7 nosing (-10.55, -8.36, 1.4) hit Mod_Upper_Shell
| Stair2_Ext | 24 | 0.175 | 0.300 | 1.80 | 3.950 m | n/a | PASS |
  - min at flight f2 i=11 centre (10.35, -1.2, 4.2) hit Mod_Roof

## Corridor clear widths (mesh-measured, mid-height)

| Corridor | Min clear (m) | Required | Result |
|---|---|---|---|
| south_corridor_ground | 2.400 | 1.80 | PASS |
| east_corridor_ground | 5.500 | 1.80 | PASS |
| north_corridor_ground | 2.500 | 1.80 | PASS |
| west_corridor_ground | 2.400 | 1.80 | PASS |
| wing_south_corridor_ground | 2.400 | 1.80 | PASS |
| south_corridor_upper | 7.300 | 1.80 | PASS |
| east_corridor_upper | 5.500 | 1.80 | PASS |
| north_corridor_upper | 2.500 | 1.80 | PASS |
| west_corridor_upper | 2.400 | 1.80 | PASS |
| gallery_south_upper | 7.500 | 1.80 | PASS |
| secure_approach_upper | 9.965 | 1.80 | PASS |

## Door and portal openings (mesh-measured)

| Name | Declared w | Measured w | Headroom | Required w | Result |
|---|---|---|---|---|---|
| Door_Main | 2.20 | 2.200 | 3.950 | 1.40 | PASS |
| Door_Service | 1.80 | 1.800 | 8.000 | 1.40 | PASS |
| Door_Stair2_Upper | 1.80 | 1.800 | 3.950 | 1.40 | PASS |
| Door_Lab_S | 1.80 | 1.800 | 3.950 | 1.40 | PASS |
| Door_Lab_E | 1.80 | 1.802 | 3.950 | 1.40 | PASS |
| Door_Equip | 1.80 | 1.800 | 3.950 | 1.40 | PASS |
| Door_Secure | 1.80 | 1.802 | 3.950 | 1.40 | PASS |
| Portal_Rec_SCorr | 2.20 | 12.000 | 3.950 | 1.80 | PASS |
| Portal_Gallery_S | 2.20 | 2.200 | 3.950 | 1.80 | PASS |
| Portal_Gallery_W | 2.20 | 2.200 | 3.950 | 1.80 | PASS |
| Portal_Wing_N_G | 2.20 | 7.700 | 3.950 | 1.80 | PASS |
| Portal_Wing_S_G | 2.20 | 7.100 | 3.950 | 1.80 | PASS |
| Portal_Wing_N_U | 2.20 | 7.700 | 3.950 | 1.80 | PASS |
| Portal_Wing_S_U | 2.20 | 7.100 | 3.950 | 1.80 | PASS |

