Texture maps live in research_annex_final_b_textures.zip (extract
alongside this zip so modules/../textures/ resolves). The assembled
and far-LOD GLBs already embed their PBR maps and can be imported
on their own. Module GLBs in this zip reference ../textures/*.png
instead of embedding a duplicate copy of every map.
