# Research Annex — final_b visual-fix report

Visual-fix copy of the playable Research Annex, for Godot 4.6.3. Same tested L-shape and routes as the Step 1 package in `/workspace/research_annex/final/` (that package was left intact). Work in this report is under `/workspace/research_annex/final_b/`.

Asymmetric 20 × 20 m main block plus an 8 × 12 m north-east wing, in a 28 × 24 m box. Ground 0.00 m, upper 4.20 m, roof 8.40 m. Main entrance on Blender −Y (Godot +Z). Service entrance on the east wall of the wing. Stair 1 is the interior straight run by reception; Stair 2 is the exterior L-stair in the SE court.

All metres.

## What changed in final_b (walkable geometry not redesigned)

The Step 1 official front 3/4 showed a solid black court/apron, thick black roof-edge and storey-band lines, and a uniform 0.5 m concrete tile grid. Those were fixed here without moving tested stair treads, rail gaps, corridor walls, door openings, or the walkable apron top (still at z = 0).

- **Ground / apron.** The black court was a z-fight: `Site_Pad`'s inner earth pad was coplanar with walkable `Mod_Apron` at z = 0, and Cycles rendered the overlap as a black void. The site inner-pad vertices were lowered 0.08 m (Site is preview-only and is not in the GLB). `Mod_Apron` was reassigned to a new `Apron_Gravel` material (pale gravel/concrete PBR). `Earth_Pad` and `Grass_Pad` now use muted green-brown forest-hill maps. Existing retaining walls were kept and retinted; ten extra low-poly trees were added at the site edges (15 trees total). Trees and the rest of Site stay out of the assembled GLB.
- **Black roof / storey / joint lines.** `Concrete_Pale_Shade` had never received PBR maps (a name typo left it untextured). `Steel_Olive_Dark` was a dark untextured metal (base 0.15, metallic 0.70) and read as black. Both were rebuilt from the olive/concrete maps, with dark olive less metallic (0.25) and lifted. Olive-steel coping strips were added on the roof perimeter and a slightly taller olive storey-band cover was added *outside* the shell (new object `Mod_Detail_Coping`, 288 triangles). Faces of that cover that crossed `Door_Stair2_Upper` were removed. Stair risers and treads were switched from near-black untextured colours to weathered concrete tints.
- **Concrete weather and seams.** New procedural 2.4 m tile maps (1024 px) use a 2.4 × 1.2 m running-bond module with offset joints and *subtle* darker-concrete seams (not black). Albedo has pale tint variation, vertical rain streaks, and sparse moss mottling. The concrete shader adds a darker 0.60 m splash band from world Z, restrained moss near the ground, and vertex-colour stain under sills, under the front canopy, under Stair 2, and around the roof edge. Box UVs were recast at 2.4 m (2.0 m on the apron). These are UV, material, and additive exterior strips only.

**Assembled building: 15,410 triangles** (was 15,122; +288 coping). Far below the 45k cap. **Far LOD: 192 triangles**, unchanged.

PBR maps were generated from procedural noise and height-to-normal (tileable, box-projected UVs). They are real image textures in Principled BSDF and in the GLB, **not a bake from a sculpted high-poly cage**.

## Geometry verification (mesh rays on `final_b/research_annex.blend`, Site and LOD hidden)

**PASS overall.** Under-flight, slab openings, and mesh-measured door and corridor widths all passed.

### Stairs

| Stair | Kind | Risers | Riser | Tread | Clear width | Min under-flight | Opening |
|---|---|---|---|---|---|---|---|
| Stair 1 | interior straight, +Y | 24 | 0.175 m | 0.30 m | 1.80 m | **2.550 m** | clear |
| Stair 2 | exterior L, 12+12 | 24 | 0.175 m | 0.30 m | 1.80 m | **3.950 m** | n/a (overhang soffit) |

### Door and portal openings (mesh-measured)

Same as Step 1: Main 2.200 m; Service / Stair-2 / Lab_S / Equip 1.800 m; Lab_E / Secure 1.802 m (2 mm sampling around beveled frames). Headroom 3.950 m at interior doors; Service 8.000 m to sky just outside. All PASS against ≥ 1.40 m w, 2.20 m h (portals ≥ 1.80 / 2.20).

Corridors remain at least 2.40 m clear (declared 2.20 m).

## Walkthroughs (final_b assembled `.glb` / `.blend`, same waypoints)

Capsule **1.8 m tall, radius 0.32 m**, step-up 0.25 m. Godot: CharacterBody3D, `floor_max_angle` 45°, `floor_snap_length` 0.4 m, trimesh at runtime, **no collision in the shipped GLB**. Door leaves hidden/skipped. Reach 0.40 m H / 0.50 m V on landings and corridors; 0.18 m / 0.12 m on consecutive treads. No nudge, teleport, or waypoint skip. Look-ahead stays disabled. The walker markdown template, which previously said look-ahead was used on level walks, now states that it is disabled. Site and the far LOD were hidden for Blender rays and are not in the assembled GLB.

**Godot is the pass/fail authority: 8 of 8 routes passed.**
**Blender ray-capsule walker: 8 of 8 routes passed.**
**verify_geometry: PASS.**

| Route | Godot | Blender | Godot min head | Godot time |
|---|---|---|---|---|
| main_to_stair1_up | 30/30 PASS | 30/30 PASS | 2.252 m | 11.6 s |
| stair1_down_to_main | 30/30 PASS | 30/30 PASS | 2.252 m | 11.0 s |
| service_to_stair2_up | 35/35 PASS | 35/35 PASS | 2.172 m | 13.9 s |
| stair2_down_to_service | 35/35 PASS | 35/35 PASS | 2.177 m | 13.3 s |
| exterior_stair_up | 32/32 PASS | 32/32 PASS | 2.172 m | 8.5 s |
| exterior_stair_down | 32/32 PASS | 32/32 PASS | 2.177 m | 8.9 s |
| ground_loop | 12/12 PASS | 12/12 PASS | 3.912 m | 21.1 s |
| upper_loop (gallery + keycard / secure-door approach; leaf skipped) | 21/21 PASS | 21/21 PASS | 2.362 m | 30.8 s |

**The 2.172 m Godot reading is a sampling artefact, not a new obstruction in final_b.** A Blender +Z ray (Site and LOD hidden, same as the GLB) from the Godot sample and from the capsule top hits the same surface in both packages:

- Hit object: `Door_Stair2_Upper_Frame`, material `Steel_Olive`, **hit_z = 6.4895 m** in both `final/` and `final_b`. `Mod_Detail_Coping` was not the hit.
- Godot computes clearance as `hit.y - feet.y` (ray starts at the capsule top, feet + 1.8 m).
- final_b sample: feet (9.172, 0.030, **4.318**), clearance 4.318 → 6.4895 = **2.1715 m** (reported 2.172). Capsule-top distance to the lintel is 0.3715 m.
- final/ sample: feet (9.176, 0.016, **4.278**), clearance 4.278 → 6.4895 = **2.2115 m** (reported 2.212).
- 4.318 + 2.172 = 4.278 + 2.212 = **6.490 m**. The 4 cm drop is exactly the 4 cm the feet were higher.

The walker’s usual standing height on this landing is z = 4.238 (see the Godot logs: `pos_blender=(…, 4.238)`). From that pose, and from the same XY, clearance is **2.2515 m** in both packages (≥ 2.25 m). The feet at the min-head sample were raised 4 cm (final/) or 8 cm (final_b) above that standing height by Godot’s 0.25 m `test_move` step-up through the door threshold, and the head sample was taken before the body snapped back down. The Blender walker, which uses a consistent floor, reported **2.289 m** on these routes (6.4895 − 4.200). verify_geometry still measures 3.950 m of volume above the opening and 3.950 m under the overhang soffit. The 1.8 m capsule cleared every waypoint (8/8). No geometry was changed for this figure. Evidence: `final_b/headroom_stair2_door.txt`.

## Caveats and what was not tested

- PBR maps are procedural (noise, running-bond seams, height-to-normal). They are not a high-poly cage bake in Cycles.
- A few residual dark lines remain at roof edges and storey splits where the original reveal sits in shadow behind the new olive coping. They are no longer thick black caps or a black margin/void.
- Some meshes (after earlier canopy / frame bevels) still produce “tangent space can only be computed for tris/quads” on export. Godot import has `meshes/ensure_tangents=true`.
- Vertex-colour stain is used in the concrete shader. Other materials may still carry an unused stain layer (gltf warning).
- **Renders are Blender Cycles only.** There is no Godot editor render.
- **No gameplay scripts, no door animation, no keycard logic.**
- **Max floor angle** on stair routes is again ~45°, the `floor_max_angle` limiter, not the 30.3° tread slope.
- **Not tested:** player controller in the editor, lighting in Godot, navmesh, combat cover, window collisions as breakables, multiplayer, or a playable Godot scene beyond the headless walker.
- Site trees, forest ground and retaining walls are preview-only and excluded from the assembled GLB and from collision.
- Lab and gallery interiors still show a thick dark band at the void slab edge (an interior plaster/slab junction, not the exterior storey band).
- The Stair 1 upward eye-level view still shows dark riser strips (Stair 2 risers read pale in exterior views).
- The equipment-room interior is the darkest official still (mean Rec.709 luma 0.381, up from 0.317 in Step 1) but is readable.
- The LOD comparison uses the same camera as the front 3/4 but with Site hidden, so it shows the apron only; the official front and rear stills include the forest-hill site and trees.
- The Stair 1 section was re-rendered as a true Y–Z elevation (z up, +Y to the right). The batch camera called `to_track_quat('-Z', 'Z')`, which is degenerate for a horizontal look along +X and had produced a plan-like view; that raw frame is kept as `renders/annex_section_stair1_raw_planlike.png` and is not an official drawing.

## Deliverables

Under `/workspace/research_annex/final_b/`:

- `research_annex.blend` (editable), `research_annex_assembled.glb` + `.glb.import` (suffix options off)
- `research_annex_lod_far.glb` + `.glb.import` (192 tris)
- `modules/` — same module set as Step 1, plus coping bundled with the props/roof modules, each with `.import` files
- `textures/` — shared albedo / normal / ORM, including new concrete (2.4 × 1.2 running bond), apron gravel, forest earth and hill grass
- This report, `triangle_counts.json`, `verify_geometry.md` / `.json`, `walkthrough_results.md` / `.json`, `godot_walker_results.md` / `.json`
- Official Cycles stills, dimensioned plans and sections, LOD comparison, and overview board (see luma table and zip list below)
- `headroom_stair2_door.txt` — Blender ray evidence for the 2.172 m Godot min-head sample
- Delivery zips (sizes filled after packing)

The untouched Step 1 package remains in `/workspace/research_annex/final/`.

## Official renders (Rec.709 mean luma)

Every official frame was viewed on disk. Mean luma is computed outside Blender (Rec.709, full-resolution RGB). Clip-low values on section drawings are the intended black cut voids, not crushed exteriors.

| Frame | Size (px) | Mean luma | Notes |
|---|---|---|---|
| annex_exterior_3q_front.png | 2400×1600 | 0.600 | Pale gravel court, olive coping/bands, weathered seams, trees. clip_lo 0.000, p1 0.004 |
| annex_exterior_3q_rear.png | 2400×1600 | 0.497 | Readable; residual thin dark reveal lines |
| annex_cutaway.png | 2400×1600 | 0.612 | Open-roof cutaway |
| annex_int_reception.png | 1920×1080 | 0.623 | 1.7 m eye |
| annex_int_lab.png | 1920×1080 | 0.733 | Dark void-edge band remains |
| annex_int_stair1.png | 1920×1080 | 0.580 | Dark upward riser strips remain |
| annex_int_gallery.png | 1920×1080 | 0.807 | Dark void-edge band remains |
| annex_int_secure_approach.png | 1920×1080 | 0.719 | 1.7 m eye |
| annex_int_stair2_mid.png | 1920×1080 | 0.603 | 1.7 m eye |
| annex_int_equipment.png | 1920×1080 | 0.381 | Darkest official interior; readable |
| annex_plan_ground.png | 3200×2800 | 0.778 | 28×24 m, corridors, doors, stairs, markers, 1.8 m figure, z = 0.00 m |
| annex_plan_upper.png | 3200×2800 | 0.788 | Same annotations; z = 4.20 m |
| annex_plans_sheet.png | 4084×5588 | 0.778 | Ground + upper plans and three sections |
| annex_section_stair1.png | 2800×1800 | 0.735 | True elevation; riser 0.175 / tread 0.30 / rise 4.20 / headroom 2.55 / 1.8 m figure |
| annex_section_stair2.png | 2800×1800 | 0.517 | L-stair; darker from cut voids; labels haloed and legible |
| annex_section_exterior.png | 2800×1800 | 0.528 | Exterior route; same |
| annex_lod_comparison.png | 4084×1543 | 0.745 | Assembled 15,410 tris vs far LOD 192, same camera, Site hidden |
| annex_overview_board.png | 4296×4101 | 0.696 | Triangle counts 15,410 / 192 and test summary in the header |

Raw plan / section / LOD frames live under `final_b/renders/` and are not all packed.

## Per-module triangle counts (assembled 15,410)

From `triangle_counts.json` (objects in the assembled GLB; Site and preview trees excluded):

| Object | Triangles |
|---|---|
| Mod_Stair2_Ext | 2,856 |
| Mod_Stair1 | 2,208 |
| Mod_Canopy | 1,840 |
| Mod_Detail_WindowsTrim | 1,644 |
| Mod_Upper_Shell | 1,060 |
| Mod_Interior_Upper | 976 |
| Mod_Ground_Shell | 824 |
| Mod_Interior_Ground | 388 |
| Door_*_Frame (7 frames) | 324 each (2,268) |
| Mod_Detail_Coping | 288 |
| Mod_Roof | 206 |
| Mod_Apron | 200 |
| Mod_Detail_RoofKit | 108 |
| Door leaves (8 leaves: Main L+R and six singles) | 68 each (544) |
| **Assembled total** | **15,410** |
| ResearchAnnex_LOD (far, separate GLB) | 192 |

## Delivery zips

Packed with Python `zipfile` only (no system `zip`). Each is tested with `ZipFile.testzip()` and is under 25,000,000 bytes (decimal). The Step 1 zips in `final/` were not modified.

Module GLBs in the models zip have their PBR images rewritten to `../textures/*.png` so the maps are not duplicated; on-disk modules in `final_b/modules/` are unchanged and still embed maps. The assembled and far-LOD GLBs keep embedded maps and import on their own. Extract the textures zip alongside the models zip so that `modules/../textures/` resolves.

| Zip | Bytes | MB (decimal) | `testzip()` | Contents |
|---|---|---|---|---|
| `research_annex_final_b_models.zip` | 13,380,243 | 13.38 | clean (`None`) | blend; assembled GLB + import (textures embedded); far LOD GLB + import (192 tris); 11 module GLBs with maps externalized to `../textures/` + their `.import` files; this report; triangle counts; verify / Blender-walker / Godot-walker results; door and stair records; headroom ray evidence; luma table; README_PACK.txt |
| `research_annex_final_b_textures.zip` | 15,480,275 | 15.48 | clean (`None`) | 27 files under `textures/` (concrete 2.4×1.2 running bond, apron gravel, forest earth, hill grass, olive steel, teal accent, roof membrane, glass, stain) |
| `research_annex_final_b_renders.zip` | 15,607,310 | 15.61 | clean (`None`) | 18 official frames: front, rear, cutaway, 7 interiors (JPEG 1600–1920); ground and upper plans + three sections (PNG 2000–2400); LOD comparison, plans sheet, overview board (JPEG) |

Full-resolution PNG stills and raw plan/section/LOD frames remain on disk under `final_b/` and `final_b/renders/` and were not all packed, so the renders zip stays under 25 MB.

Models-zip file list (41 entries): `research_annex.blend`, `research_annex_assembled.glb` (+ `.import`), `research_annex_lod_far.glb` (+ `.import`), `modules/research_annex_{apron,canopy,doors,ground_shell,interior_ground,interior_upper,props,roof,stair1,stair2_exterior,upper_shell}.glb` (+ `.import` each), `FINAL_REPORT.md`, `triangle_counts.json`, `verify_geometry.md`, `verify_geometry.json`, `walkthrough_results.md`, `walkthrough_results.json`, `walkthrough_waypoints.json`, `godot_walker_results.md`, `godot_walker_results.json`, `door_openings.json`, `stair_records.json`, `headroom_stair2_door.txt`, `luma_official.json`, `README_PACK.txt`.

